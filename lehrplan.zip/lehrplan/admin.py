from django.contrib import admin

from .models import Rahmenlehrplan

# Register your models here.
admin.site.register(Rahmenlehrplan)